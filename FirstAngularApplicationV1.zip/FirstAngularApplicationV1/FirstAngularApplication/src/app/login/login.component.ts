import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HardcodedAuthenticationServiceService } from '../service/hardcoded-authentication-service.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
username ='bhanu'
password =''
invalidLoging = false
errmsg ='invalid credentials'

//Router
//angular.giveme router
//navigate the Login page to welcome . 
//  Dependency Injection.
  constructor(private router : Router, 
    private hardcodedAuthenticationServiceService : HardcodedAuthenticationServiceService) {  }

  ngOnInit() {
  }

  handleLogin(){
    console.log(this.username)
   // console.log(this.password)
 
    if(this.hardcodedAuthenticationServiceService.authenticate(this.username,this.password)){
     //naviget to welcome page
      this.router.navigate(['welcome',this.username])
    this.invalidLoging = false
   } else{
    this.invalidLoging = true
   }
  }

}
