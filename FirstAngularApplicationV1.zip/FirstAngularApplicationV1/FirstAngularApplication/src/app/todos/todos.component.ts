import { Component, OnInit } from '@angular/core';

export class Todo{

  constructor(
    public id: number,
    public name: String,
    public targetData: Date
    ){

  }
}

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})


export class TodosComponent implements OnInit {
todos = [
  //created todo class and created obj with details
  new Todo(101,'bhanu',new Date()),
  new Todo(102,'prakash', new Date()),
  new Todo(103,'kolli', new Date())
 /* { id:101, name:"bhannu"},
  { id:102, name:"prakash"},
  { id:103, name:"kolli"} */
]
  constructor() { }

  ngOnInit() {
  }

}
