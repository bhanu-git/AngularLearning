import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export class HelloWorldBean{

  constructor(private message: String){

  }
}

@Injectable({
  providedIn: 'root'
})
export class WelcomeDataServiceService {

  constructor(private http : HttpClient) { }

  executeHelloWorldBeanService(){
    return this.http.get<HelloWorldBean>("http://localhost:8080/hello-world-bean/");
   // console.log("execute hello worldbean service")
   //console.log(this.http.get("http://localhost:8080/hello-world-bean/"));
  }
}
