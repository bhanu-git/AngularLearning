import { Component, OnInit } from '@angular/core';
import { HardcodedAuthenticationServiceService } from '../service/hardcoded-authentication-service.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

 // isUserLogin : Boolean = false;
  constructor(private hardcodedAuthenticationServiceService : HardcodedAuthenticationServiceService) { }

  ngOnInit() {

     // this.isUserLogin = this.hardcodedAuthenticationServiceService.isUserLogin();

  }

}
