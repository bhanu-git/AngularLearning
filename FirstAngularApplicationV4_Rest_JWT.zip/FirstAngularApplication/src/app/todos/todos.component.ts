import { Component, OnInit } from '@angular/core';
import { TodosDataServiceService } from '../service/data/todos-data-service.service';
import { Router } from '@angular/router';

export class Todo{

  constructor(
    public id: number,
    public name: String,
    public targetData: Date
    ){

  }
}

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})


export class TodosComponent implements OnInit {
todos : Todo[]
deletemessage : String

//[
  //created todo class and created obj with details
 // new Todo(101,'bhanu',new Date()),
 // new Todo(102,'prakash', new Date()),
 // new Todo(103,'kolli', new Date())
 /* { id:101, name:"bhannu"},
  { id:102, name:"prakash"},
  { id:103, name:"kolli"} */
//]
  constructor(private todosservice : TodosDataServiceService,
              private router : Router) { }

  ngOnInit() {
    this.refreshTodos();
  }

  refreshTodos(){
    this.todosservice.retriveAllTodos("bhanu").subscribe(
      response => {
        this.todos = response;
      }
    )
  }
  deleteTodos(id){
    //console.log("delet todo");
    this.todosservice.deleteTodos("bhanu",id).subscribe(
      response => {
        this.deletemessage = `deleted Todo ${id} successfull!!!`;
        this.refreshTodos()
      }
    )
    
  }

  updateTodos(id){
    console.log("update todos");
    this.router.navigate(['todos',id])
  }

  addTodos(){
    this.router.navigate(['todos',-1])
  }

}
