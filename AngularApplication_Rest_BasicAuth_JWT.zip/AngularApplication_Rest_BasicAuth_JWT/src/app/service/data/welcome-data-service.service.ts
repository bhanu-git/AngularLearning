import { Injectable } from '@angular/core';
import { HttpClient, HttpHandler, HttpHeaders } from '@angular/common/http';

export class HelloWorldBean{

  constructor(private message: String){

  }
}

@Injectable({
  providedIn: 'root'
})
export class WelcomeDataServiceService {

  constructor(private http : HttpClient) { }

  executeHelloWorldBeanService(){
    //with out authentication 
   //return this.http.get<HelloWorldBean>("http://localhost:8080/hello-world-bean/");

   //with authentication , we must pass the header information 
    let basicAuthHeaderString = this.createBasicAuthenticationHttpHeader();
    let headers = new HttpHeaders({
      Authorization : basicAuthHeaderString
    })

    return this.http.get<HelloWorldBean>("http://localhost:8080/hello-world-bean/",{headers});
   // console.log("execute hello worldbean service")
   //console.log(this.http.get("http://localhost:8080/hello-world-bean/"));
  }

  executeHelloWorldBeanErrorService(){
    return this.http.get<HelloWorldBean>("http://localhost:8080/hello-world-bean/error");
   // console.log("execute hello worldbean service")
   //console.log(this.http.get("http://localhost:8080/hello-world-bean/"));
  }

  executeHelloWorldBeanServicewithPathVariable(name){

    //with out authentication no headers required.
    //return this.http.get<HelloWorldBean>(`http://localhost:8080/hello-world-bean/path-variable/${name}`);
    
    let basicAuthHeaderString = this.createBasicAuthenticationHttpHeader();
    let headers = new HttpHeaders({
      Authorization : basicAuthHeaderString
    })
    //with authentication headers
    return this.http.get<HelloWorldBean>(`http://localhost:8080/hello-world-bean/path-variable/${name}`,{headers:headers});
  
    // console.log("execute hello worldbean service")
   //console.log(this.http.get("http://localhost:8080/hello-world-bean/"));
  }

/*
Access to XMLHttpRequest at 'http://localhost:8080/hello-world-bean/' 
from origin 'http://localhost:4200' has been blocked by CORS policy:
 No 'Access-Control-Allow-Origin' header is present on the requested resource.
zone.js:3243 GET http://localhost:8080/hello-world-bean/ net::ERR_FAILED

solution: need to send the HttpHeader info throuth request.
*/ 

createBasicAuthenticationHttpHeader(){
  let username = 'admin'
  let password = 'admin'

  let basicAuthHeaderString = 'Basic '+ window.btoa(username+':'+password);
  return basicAuthHeaderString;
  
}

/*
Access to XMLHttpRequest at 'http://localhost:8080/hello-world-bean/path-variable/bhanu' 
from origin 'http://localhost:4200' has been blocked by CORS policy:
Response to preflight request doesn't pass access control check: 
It does not have HTTP ok status.

Solution: adding .antMatchers(HttpMethod.OPTIONS,"/**").permitAll()  in springboot security configuration to permit the optional header.

*/

}

