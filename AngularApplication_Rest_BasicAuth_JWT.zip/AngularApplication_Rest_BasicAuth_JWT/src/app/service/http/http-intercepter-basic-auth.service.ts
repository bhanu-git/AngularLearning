import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { BasicAuthenticationServiceService } from '../basic-authentication-service.service';

@Injectable({
  providedIn: 'root'
})
//This class will provide the common header setting to each request.
//This needs to be register in provider in app.module.ts file
export class HttpIntercepterBasicAuthService implements HttpInterceptor {

  constructor(private basicAuthenticationService : BasicAuthenticationServiceService) { }

  intercept(request: HttpRequest<any>, next: HttpHandler){

    //let username = 'admin'
    //let password = 'admin'
    //let basicAuthHeaderString = 'Basic '+ window.btoa(username+':'+password);

    let isUserLogin = this.basicAuthenticationService.isUserLogin();
    if(isUserLogin){
      let basicAuthHeaderString = this.basicAuthenticationService.getAuthenticatedToken();
      let username = this.basicAuthenticationService.getAuthenticatedUser();
    
    if(basicAuthHeaderString && username){
          request = request.clone({
              setHeaders : {
                Authorization : basicAuthHeaderString
              }
          })
      }
    }
    return next.handle(request);
  }
}


