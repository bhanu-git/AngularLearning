import { Component, OnInit } from '@angular/core';
import { TodosDataServiceService } from '../service/data/todos-data-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Todo } from '../todos/todos.component';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

  id : number
  todo : Todo
  constructor(private service : TodosDataServiceService,
             private route : ActivatedRoute,
             private router : Router) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id']
    console.log("id value"+this.id)
    this.todo = new Todo(this.id,'',new Date())
    if(this.id != -1){
        this.service.retriveTodo("bhanu",this.id).subscribe(
        
        
          data => {
            this.todo = data
          }
          
        )
    }
  }


  saveTodo(){
    //logic to create new Todo
    if(this.id == -1){
      this.service.createTodo("bhanu",this.todo).subscribe(
        data =>{
          console.log(data)
              this.router.navigate(['todos'])
        }
      )
    }//logic to update Todo
    else{
          this.service.updateTodo("bhanu",this.id,this.todo).subscribe(
            data => {
              console.log(data)
              this.router.navigate(['todos'])
            }
          )
    }
  }
}
