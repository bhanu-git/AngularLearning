import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WelcomeDataServiceService } from '../service/data/welcome-data-service.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  name = ''
  welcomeMessageFromService : String
  errorMessageFromService : String
  welcomeMessagewithPathVariableFromService : String
  //ActivatedRoute
  constructor(private route : ActivatedRoute,
    private service : WelcomeDataServiceService) { }

  ngOnInit() {
    this.name = this.route.snapshot.params['name']
  }

  getWelcomeMessage(){
    console.log(this.service.executeHelloWorldBeanService());
    //this is asyncronize call.
    this.service.executeHelloWorldBeanService().subscribe(
      response => this.handleSuccessfulResponse(response)
    );

    console.log("last line of getwelcomemessage")
  }

  handleSuccessfulResponse(response){
    this.welcomeMessageFromService = response.message;
    //console.log(response);
    //console.log(response.message);
  }

  //Handling error messages 
  getErrorMessage(){
    this.service.executeHelloWorldBeanErrorService().subscribe(
      response => this.handleSuccessfulResponse(response),
      error => this.handleErrorResponse(error)
    );
  }

  handleErrorResponse(error){
    //console.log(error.error.message);
    this.errorMessageFromService = error.error.message;
   
  }

  getWelcomeMessageWithPathVariable(){
    console.log(this.service.executeHelloWorldBeanService());
    //this is asyncronize call.
    this.service.executeHelloWorldBeanServicewithPathVariable(this.name).subscribe(
      response => this.handleSuccessfulResponsewithPathVariable(response)
    );

  }

  handleSuccessfulResponsewithPathVariable(response){
    this.welcomeMessagewithPathVariableFromService = response.message;
  }

}
