import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Todo } from 'src/app/todos/todos.component';

@Injectable({
  providedIn: 'root'
})
export class TodosDataServiceService {

  constructor(private http : HttpClient) { }

  retriveAllTodos(username){
    return this.http.get<Todo[]>(`http://localhost:8080/users/${username}/todos`);
  }

  //DELETE request
  deleteTodos(username,id){
    return this.http.delete(`http://localhost:8080/users/${username}/todos/${id}`);
  }

  retriveTodo(username, id){
    return this.http.get<Todo>(`http://localhost:8080/users/${username}/todos/${id}`);
  }

  //Put request
  updateTodo(username, id, todo){
    return this.http.put(`http://localhost:8080/users/${username}/todos/${id}`,todo);
  }

  //post request
  createTodo(username, todo){
    return this.http.post(`http://localhost:8080/users/${username}/todos`,todo);
  }

}
