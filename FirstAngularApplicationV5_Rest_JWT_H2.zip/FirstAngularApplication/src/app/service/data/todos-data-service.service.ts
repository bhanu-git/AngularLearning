import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Todo } from 'src/app/todos/todos.component';
import { API_URL, JPA_API_URL } from 'src/app/app.constants';

@Injectable({
  providedIn: 'root'
})
export class TodosDataServiceService {

  constructor(private http : HttpClient) { }

  retriveAllTodos(username){
    //API_URL = http://localhost:8080  defined in app.constants.ts file
    //return this.http.get<Todo[]>(`${API_URL}/users/${username}/todos`);
    return this.http.get<Todo[]>(`${JPA_API_URL}/users/${username}/todos`);
    
  }

  //DELETE request
  deleteTodos(username,id){
    //return this.http.delete(`${API_URL}/users/${username}/todos/${id}`);
    return this.http.delete(`${JPA_API_URL}/users/${username}/todos/${id}`);
  }

  retriveTodo(username, id){
    //return this.http.get<Todo>(`${API_URL}/users/${username}/todos/${id}`);
    return this.http.get<Todo>(`${JPA_API_URL}/users/${username}/todos/${id}`);
  }

  //Put request
  updateTodo(username, id, todo){
    //return this.http.put(`${API_URL}/users/${username}/todos/${id}`,todo);
    return this.http.put(`${JPA_API_URL}/users/${username}/todos/${id}`,todo);
  }

  //post request
  createTodo(username, todo){
    //return this.http.post(`${API_URL}/users/${username}/todos`,todo);
    return this.http.post(`${JPA_API_URL}/users/${username}/todos`,todo);
  }

}
