import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HardcodedAuthenticationServiceService {

  constructor() { }

  authenticate(username,password){
    //console.log(this.isUserAuthenticate())
    if(username === "admin" && password === "admin"){
      sessionStorage.setItem("userauthenticate",username);
     // console.log(this.isUserAuthenticate())
      return true;
    }
    return false;
  }

  isUserLogin(){

    let user = sessionStorage.getItem("userauthenticate");
    return !(user === null)

  }

  logout(){
    sessionStorage.removeItem("userauthenticate");
  }
}
