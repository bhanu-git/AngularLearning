import { TestBed } from '@angular/core/testing';

import { TodosDataServiceService } from './todos-data-service.service';

describe('TodosDataServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TodosDataServiceService = TestBed.get(TodosDataServiceService);
    expect(service).toBeTruthy();
  });
});
