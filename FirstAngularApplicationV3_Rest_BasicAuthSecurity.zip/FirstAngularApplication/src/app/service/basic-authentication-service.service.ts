import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import {map} from 'rxjs/operators';
import { API_URL } from '../app.constants';

export const AUTHENTICATED_USER = 'userauthenticate'
export const TOKEN = 'token'

@Injectable({
  providedIn: 'root'
})


export class BasicAuthenticationServiceService {

  constructor(private http: HttpClient) { }

  
  executeBasicAuthenticationService(username, password){
    let basicAuthHeaderString = 'Basic '+ window.btoa(username+':'+password);
     
    let headers = new HttpHeaders({
      Authorization : basicAuthHeaderString
    })
    //with authentication headers
    return this.http.get<AuthenticationBean>(`${API_URL}/basicauth`,
                      {headers}).pipe(
                        map(
                            data => {
                              
                              sessionStorage.setItem(AUTHENTICATED_USER, username);
                              sessionStorage.setItem(TOKEN, basicAuthHeaderString);
                              
                              return data;
                            }
                        )
                        
                      );
  
   
  }
  
   getAuthenticatedUser(){
    //let user = sessionStorage.getItem('userauthenticate')
    //console.log("user getAuthentucate method "+ user);
    return "admin"
  }

   getAuthenticatedToken(){
    if(this.getAuthenticatedUser()){
        return sessionStorage.getItem(TOKEN);
    }
  }
  isUserLogin(){

    let user = sessionStorage.getItem(AUTHENTICATED_USER);
    return !(user === null)

  }

  logout(){
    sessionStorage.removeItem(AUTHENTICATED_USER);
    sessionStorage.removeItem(TOKEN);
  }

  


}

export class AuthenticationBean{
  constructor(){}
}

/*
Access to XMLHttpRequest at 'http://localhost:8080/hello-world-bean/' 
from origin 'http://localhost:4200' has been blocked by CORS policy:
 No 'Access-Control-Allow-Origin' header is present on the requested resource.
zone.js:3243 GET http://localhost:8080/hello-world-bean/ net::ERR_FAILED

solution: need to send the HttpHeader info throuth request.
*/ 